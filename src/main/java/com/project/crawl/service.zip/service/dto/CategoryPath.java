package com.project.crawl.service.dto;

import lombok.Data;

@Data
public class CategoryPath {
    private Integer idx;
    private String category_path;
}
