package com.project.crawl.service.dto;

import lombok.Data;

@Data
public class DetailShopInfo {
    public String shop_name;
    public String shop_url;
    public String seller_login_id;
    public String seller_user_id;
    public String seller_member_id;
}