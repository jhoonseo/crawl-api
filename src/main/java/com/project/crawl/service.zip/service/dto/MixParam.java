package com.project.crawl.service.dto;

import lombok.Data;

@Data
public class MixParam {
    public int mixAmount;
    public int mixBegin;
    public int mixNum;
    public int shopMixNum;
    public boolean supportMix;
}