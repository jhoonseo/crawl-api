package com.project.crawl.service.dto;

import lombok.Data;

@Data
public class PriceInfo {
    public String drop_ship_price;
    public String wholesale_price;
    public String origin_price;
    // ... Add other fields as necessary
}