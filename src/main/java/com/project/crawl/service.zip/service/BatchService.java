package com.project.crawl.service;

import com.project.crawl.controller.CrawlCategoryController;
import com.project.crawl.controller.FileController;
import com.project.crawl.controller.CrawlProductController;
import com.project.crawl.controller.dto.*;
import com.project.crawl.dao.C24ProductDao;
import com.project.crawl.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BatchService {
    @Value("${cdn.base.url.costco:}")
    private String cdnBaseUrlCostco;

    @Value("${local.daily.directory.costco}")
    private String localDailyDirectoryCostco;

    private final CategoryService categoryService;
    private final ProductService productService;
    private final CrawlService crawlService;
    private final C24ProductService c24ProductService;
    private final CommonUtil commonUtil;
    private final ResizeService resizeService;
    private final FtpService ftpService;
    private final S3Service s3Service;
    private final ExcelService excelService;
    private final RestrictedKeywordService restrictedKeywordService;
    private final C24XlsxService c24XlsxService;
    private final C24ProductDao c24ProductDao;
    private final CrawlCategoryController crawlCategoryController;
    private final CrawlProductController crawlProductController;
    private final FileController fileController;

    public void runCostcoBatchJob() throws IOException {

    }

    private void processC24ImageMissingOrNotNukkiProduct(LocalDate today) {
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));
        List<C24Product> c24ProductList = c24ProductDao.getAllC24ProductCostcoList();
        Map<Long, C24ProductThumb> c24ProductThumbMap = new HashMap<>();
        List<Long> errorProductCodeList = new ArrayList<>();

        c24ProductList.forEach(c24CostcoProduct -> {
            C24ProductThumb c24ProductThumb = new C24ProductThumb();
            List<String> thumbUrls = new ArrayList<>();
            String thumbMain = c24CostcoProduct.getThumbMain();
            String thumbExtra = c24CostcoProduct.getThumbExtra();
            thumbUrls.add(thumbMain);
            if (thumbExtra != null) {
                thumbUrls.addAll(Arrays.stream(thumbExtra.split("\\|")).toList());
            }

            c24ProductThumb.setThumbUrlList(thumbUrls);
            c24ProductThumb.setCommonC24Product(c24CostcoProduct);
            c24ProductThumbMap.put(c24CostcoProduct.getProductCode(), c24ProductThumb);
        });

        c24ProductThumbMap.forEach((k, c24T) -> {
            List<String> thumbUrlList = c24T.getThumbUrlList();
            List<String> filteredList = thumbUrlList.stream()
                    .filter(Objects::nonNull)
                    .filter(commonUtil::isNukkiImage)
                    .filter(url -> commonUtil.imageDownloadAfterCheckCostco(url, formatToday))
                    .collect(Collectors.toCollection(ArrayList::new));


            if (filteredList.size() != thumbUrlList.size()) {
                StringBuilder thumbDetailInfo = new StringBuilder();
                if (filteredList.isEmpty()) {
                    errorProductCodeList.add(k);
                    return;
                }
                List<String> filteredFileNameList = filteredList.stream()
                        .map(imageUrl -> imageUrl.split("/")[imageUrl.split("/").length - 1])
                        .collect(Collectors.toCollection(ArrayList::new));
                filteredFileNameList.forEach(fileName -> {
                    String src = String.join("/", cdnBaseUrlCostco, fileName);
                    thumbDetailInfo.append("<img src='").append(src)
                            .append("' style='width: 100%; margin-bottom:60px;'/>\n ");
                });

                String thumbMain = filteredList.get(0);
                filteredList.remove(0);
                filteredFileNameList.remove(0);
                String thumbExtraString = String.join("|", filteredList);
                String thumbExtraFilenameString = String.join("|", filteredFileNameList);
                c24ProductDao.updateThumbsInfoByProductCode(k, thumbMain, thumbExtraString, thumbExtraFilenameString, thumbDetailInfo.toString());

                System.out.format("updated productCode : %s\n", k);
            }



        });

        System.out.println(errorProductCodeList);





    }

    public void deleteC24Products(String[] c24CodesArray) {
        List<String> list = Arrays.asList(c24CodesArray);

        c24ProductDao.deleteC24ProductByC24CodeCollection(list);
    }

    public void updateC24ThumbDetail() {
        Map<Integer, C24Product> all = c24ProductDao.getAllC24Product();
        for (Map.Entry<Integer, C24Product> kv : all.entrySet()) {
            Integer idx = kv.getKey();
            C24Product val = kv.getValue();

            HashMap<String, String> fileMap = new HashMap<>();
            StringBuilder thumbDetailInfo = new StringBuilder();
            if (val.getThumbMain() == null) {
                continue;
            }
            fileMap.put(val.getThumbMain(), val.getThumbMainFilename());
            String extraFiles = val.getThumbExtra();
            fileMap.putAll(Arrays.stream(extraFiles.split("\\|"))
                    .collect(Collectors.toMap(extraFile -> extraFile, this::getThumbFilename, (existingValue, newValue) -> existingValue)));
            if (fileMap.size() == 0) {
                continue;
            }
            List<String> filenameList = new ArrayList<>(fileMap.values());
            List<String> fileUrlList = new ArrayList<>(fileMap.keySet());

            filenameList.forEach(fileName -> {
                String src = String.join("/", cdnBaseUrlCostco, fileName);
                thumbDetailInfo.append("<img src='").append(src)
                    .append("' style='width: 100%; margin-bottom:60px;'/>\n ");
            });

            String thumbMain = fileUrlList.get(0);
            fileUrlList.remove(0);
            filenameList.remove(0);
            String thumbExtraString = String.join("|", fileUrlList);
            String thumbExtraFilenameString = String.join("|", filenameList);

            c24ProductDao.updateThumbsInfoByIdx(idx, thumbMain, thumbExtraString, thumbExtraFilenameString, thumbDetailInfo.toString());
            System.out.format("updated idx %s\n", idx);
        }
    }

    private String getThumbFilename(String url) {
        String[] splitPath = url.split("/");
        return splitPath[splitPath.length - 1];
    }

    public void generateDisableExcelByC24CodesArray(LocalDate today, String[] c24CodesArray) {
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));
        List<C24ProductXlsx> allList = c24XlsxService.getAllC24CostcoProductXlsxList();

        List<C24ProductXlsx> disableList = allList.stream()
                .filter(c24CostcoProductXlsx -> Arrays.asList(c24CodesArray).contains(c24CostcoProductXlsx.getC24Code()))
                .toList();


        // 판매 불가능 상품 엑셀 만들기
        List<C24ProductChunk> duplicatedChunks = excelService.divideList(disableList, 800);
        for (C24ProductChunk chunk : duplicatedChunks) {
            excelService.generateC24ProductExcels(chunk, formatToday, false, "costco");
        }
    }

    public void resendAllTemporarySavedAtMarketPlus() {
        String mpLoginUrl = "https://eclogin.cafe24.com/Shop/?mode=mp";
        String temporarySavedUrl = "https://mp.cafe24.com/mp/product/front/manageList?search_sending_status%5B0%5D=send_status_W&search_sending_status%5B1%5D=send_status_F&search_sending_status%5B2%5D=send_status_T&search_selling_status[]=G&search_time_type=B&search_begin_ymd=2022-06-08&search_end_ymd=2023-06-08&date_type=365";
        crawlService.setDriverProperty();
        WebDriver driver = crawlService.createWebDriver();

        driver.get(mpLoginUrl);
        crawlService.sleepMilliSec(1000);
        driver.findElement(By.id("mall_id")).sendKeys("cokomomall");
        driver.findElement(By.id("userpasswd")).sendKeys("416107ab**");
        driver.findElement(By.className("btnStrong")).click();
        crawlService.sleepMilliSec(3000);
        driver.findElement(By.id("iptBtnEm")).click();
        crawlService.sleepMilliSec(5000);
        ((JavascriptExecutor) driver).executeScript("return true;");
        driver.get(temporarySavedUrl);
        crawlService.sleepMilliSec(5000);
        ((JavascriptExecutor) driver).executeScript("return true;");

        WebElement selectCountElement = driver.findElement(By.className("eLimit"));
        Select selectCount = new Select(selectCountElement);
        selectCount.selectByValue("100");
        crawlService.sleepMilliSec(3000);

        for (int i = 0; i < 1000; i++) {
            driver.findElement(By.className("allCk")).click();
            crawlService.sleepMilliSec(1000);
            driver.findElement(By.className("cmd_action")).findElement(By.tagName("li")).findElement(By.tagName("a")).click();
            crawlService.sleepMilliSec(3000);
            driver.findElement(By.className("eBtnSearch")).click();
            crawlService.sleepMilliSec(3000);
        }

    }

    public void deleteProductFromCafe24Admin(String[] c24CodesArray) {
        crawlService.setDriverProperty();
        WebDriver driver = crawlService.createWebDriver();
        List<String> slicedKeys = new ArrayList<>();
        for (int i = 0; i < c24CodesArray.length; i += 50) {
            int endIndex = Math.min(i + 50, c24CodesArray.length);
            String[] slicedArray = Arrays.copyOfRange(c24CodesArray, i, endIndex);
            slicedKeys.add(String.join(",", slicedArray));
        }

        driver.get("https://eclogin.cafe24.com/Shop/");
        crawlService.sleepMilliSec(1000);
        driver.findElement(By.id("mall_id")).sendKeys("cokomomall");
        driver.findElement(By.id("userpasswd")).sendKeys("416107ab**");
        driver.findElement(By.className("btnStrong")).click();
        crawlService.sleepMilliSec(5000);
        driver.findElement(By.id("iptBtnEm")).click();
        crawlService.sleepMilliSec(5000);
        driver.get("https://cokomomall.cafe24.com/disp/admin/shop1/product/productmanage?eField%5B%5D=product_code&eValue%5B%5D=&Trend%5B%5D=&Brand%5B%5D=&Supplier%5B%5D=&Manufacturer%5B%5D=&Classification%5B%5D=&Condition%5B%5D=N&Globalorigin%5B%5D=&origin_level1%5B%5D=F&place_parent_no%5BF%5D%5B%5D=&place_parent_no%5BT%5D%5B%5D=&origin_place_no%5B%5D=&made_in%5B%5D=&product_type=all&categorys%5B%5D=&categorys%5B%5D=&categorys%5B%5D=&categorys%5B%5D=&category=0&date=regist&date_type=-1&display=A&selling=A&market_selecter=A&market_search_type=market&display_division=&UseStock=A&stockcount%5B%5D=stock&stock_min%5B%5D=&stock_max%5B%5D=&stock_importance=T&use_soldout=A&soldout_status=A&item_display=A&item_selling=A&price%5B%5D=product&price_min%5B%5D=&price_max%5B%5D=&page=1&orderby=regist_d&limit=100&default_column%5Bshop_product_name%5D=T&default_column%5Bmarket_interlock%5D=T&default_column%5Bsale_price%5D=T&default_column%5Bmobile_sale_price%5D=T&bIsSearchClickAction=T");
        crawlService.sleepMilliSec(3000);

        for (int i = 0; i < slicedKeys.size(); i++) {
            System.out.format("sliced key i : %S\n", i);
            String slicedKey = slicedKeys.get(i);
            WebElement searchInput = driver.findElement(By.className("eSearchText"));
            searchInput.clear();
            searchInput.sendKeys(slicedKey);
            driver.findElement(By.id("eBtnSearch")).click();
            crawlService.sleepMilliSec(3000);
            driver.findElement(By.className("allChk")).click();
            crawlService.sleepMilliSec(1000);
            driver.findElement(By.className("_manage_delete")).click();
            crawlService.sleepMilliSec(500);
            driver.switchTo().alert().accept();
            crawlService.sleepMilliSec(1000);
            try {
                driver.switchTo().alert().accept();
            } catch (Exception ignored) {
            }
            crawlService.sleepMilliSec(1000);
            driver.switchTo().window(driver.getWindowHandle());
            crawlService.sleepMilliSec(3000);
        }
    }

    public void getItemScoutKeywordsFromLink(String link) {
        crawlService.setDriverProperty();
        WebDriver driver = crawlService.createWebDriver();
        WebDriverWait wait = crawlService.createWebDriverWait(driver, 10);
        driver.get(link);
        crawlService.sleepMilliSec(10000);

        List<WebElement> keywordLabels = driver.findElements(By.className("keyword-label"));
        for (WebElement keywordLabel : keywordLabels) {
            System.out.println(keywordLabel.getText());
        }
    }
}
