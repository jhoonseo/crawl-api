package com.project.crawl.service.dto;

import lombok.Data;

@Data
public class SkuParam {
    public int beginAmount;
    public double price;
}