package com.project.crawl.controller;

import com.project.crawl.dao.ProductDao;
import com.project.crawl.exceptions.CrawlException;
import com.project.crawl.service.CrawlService;
import com.project.crawl.service.TranslateService;
import com.project.crawl.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RequiredArgsConstructor
@Slf4j
@RestController
@RequestMapping("/run")
public class TestController {

    private final CrawlCategoryController crawlCategoryController;
    private final CrawlProductController crawlProductController;
    private final FileController fileController;
    private final CrawlService crawlService;
    private final CommonUtil commonUtil;
    private final TranslateService translateService;
    private final ProductDao productDao;

    @Value("${local.images.directory.1688}")
    private String localImagesDirectory1688;
    // localImagesDirectory1688 디렉토리에는 상품 썸네일 및 상품상세 이미지가 모두 저장됨

    @Value("${local.daily.directory.1688}")
    private String localDailyDirectory1688;

    @Value("${local.ko.directory.1688}")
    private String localKoDirectory1688;

    @GetMapping("/costco-a")
    public String runCostcoA() throws IOException {
        // mysql.server start
        // https://googlechromelabs.github.io/chrome-for-testing/
        // http://localhost:5001/run/costco-a
        LocalDate today = LocalDate.now();
        crawlCategoryController.renewCategory();
        System.out.println("renewCategory() finished");
        crawlProductController.renewCostcoProduct(today);
        System.out.println("renewProduct() finished");
        fileController.resizeDailyImages(today);
        System.out.println("resizeDailyImages() finished");
        return "process finished";
    }

    @GetMapping("/costco-d")
    public String runCostcoD() throws IOException {
        // disabling category and product created a year ago
        // http://localhost:5001/run/costco-d
        LocalDate today = LocalDate.now();
        LocalDate todayYearAgo = today.minusYears(1);

        return "process finished";
    }

    @GetMapping("/costco-fix")
    public String runCostcoFix() throws IOException {
        // http://localhost:5001/run/costco-fix 이후에 costco-b 실행해야지 이미지 미등록 이슈로 c24CodeList 에 등록된 상품들의 이미지가 ftp 업로드 처리됨.
        // http://localhost:5001/run/costco-b
        LocalDate today = LocalDate.now();
//        List<String> c24CodeList = Arrays.asList("P000BAWS", "P000BBAH", "P0000VKI", "P000BLSZ", "P000BLSX", "P000BLTA", "P000BLTB", "P000BLTD", "P000BLTF", "P000BLTK", "P000BLTL", "P000BLTM", "P000BLTN", "P000BLTX", "P000BLTZ", "P000BLUA", "P000BLUB", "P000BLUC", "P000BLUD", "P000BLUE", "P000BLUF", "P000BLUH", "P000BLUI", "P000BLUJ", "P000BLUK", "P000BLUL", "P000BLUM", "P000BLUN", "P000BLUP", "P000BLUQ", "P000BLUX", "P000BLUY", "P000BLUZ", "P000BLVA", "P000BLVB", "P000BLVC", "P000BLVD", "P000BLVE", "P000BLVF", "P000BLVH", "P000BMEP", "P000BMEO", "P000BMEN", "P000BMEM", "P000BMEL", "P000BMEK", "P000BMEJ", "P000BMEI", "P000BMEH", "P000BMEG", "P000BMEF", "P000BMEE", "P000BMED", "P000BMEC", "P000BMEB", "P000BMEA", "P000BMDZ", "P000BMDY", "P000BMDX", "P000BMDW", "P000BMDV", "P000BMDU", "P000BMDT", "P000BMDS", "P000BMDR", "P000BMDQ", "P000BMDP", "P000BMDO", "P000BMDN", "P000BMDM", "P000BMDL", "P000BMDK", "P000BMDJ", "P000BMDI", "P000BMDH", "P000BMDG", "P000BMDF", "P000BMDE", "P000BMDD", "P000BMDC", "P000BMDB", "P000BMDA", "P000BMCZ", "P000BMCY", "P000BMCX", "P000BMCW", "P000BMCV", "P000BMCU", "P000BMCT", "P000BMCS", "P000BMCR", "P000BMCQ", "P000BMCP", "P000BMCO", "P000BMCN", "P000BMCM", "P000BMCL", "P000BMCK", "P000BMCJ", "P000BMCI", "P000BMCH", "P000BMCG", "P000BMCF", "P000BMCE", "P000BMCD", "P000BMCC", "P000BMCB", "P000BMCA", "P000BMBZ", "P000BMBY", "P000BMBX", "P000BMBW", "P000BMBV", "P000BMBU", "P000BMBT", "P000BMBS", "P000BMBR", "P000BMBQ", "P000BMBP", "P000BMBO", "P000BMBN", "P000BMBM", "P000BMBL", "P000BMBK", "P000BMBJ", "P000BMBI", "P000BMBH", "P000BMBG", "P000BMBF", "P000BMBE", "P000BMBD", "P000BMBC", "P000BMBB", "P000BMBA", "P000BMAZ", "P000BMAY", "P000BMAX", "P000BMAW", "P000BMAV", "P000BMAU", "P000BMAT", "P000BMAS", "P000BMAR", "P000BMAQ", "P000BMAP", "P000BMAO", "P000BMAN", "P000BMAM", "P000BMAL", "P000BMAK", "P000BMAJ", "P000BMAI", "P000BMAH", "P000BMAG", "P000BMAF", "P000BMAE", "P000BMAD", "P000BMAC", "P000BMAB", "P000BMAA", "P000BLZZ", "P000BLZY", "P000BLZX", "P000BLZW", "P000BLZV", "P000BLZU", "P000BLZT", "P000BLZS", "P000BLZR", "P000BLZQ", "P000BLZP", "P000BLZO", "P000BLZN", "P000BLZM", "P000BLZL", "P000BLZK", "P000BLZJ", "P000BLZI", "P000BLZH", "P000BLZG", "P000BLZF", "P000BLZE", "P000BLZD", "P000BLZC", "P000BLZB", "P000BLZA", "P000BLYZ", "P000BLYY", "P000BLYX", "P000BLYW", "P000BLYV", "P000BLYU", "P000BLYT", "P000BLYS", "P000BLYR", "P000BLYQ", "P000BLYP", "P000BLYO", "P000BLYN", "P000BLYM", "P000BLYL", "P000BLYK", "P000BLYJ", "P000BLYI", "P000BLYH", "P000BLYG", "P000BLYF", "P000BLYE", "P000BLYD", "P000BLYC", "P000BLYB", "P000BLYA", "P000BLXZ", "P000BLXY", "P000BLXX", "P000BLXW", "P000BLXV", "P000BLXU", "P000BLXT", "P000BLXS", "P000BLXR", "P000BLXQ", "P000BLXP", "P000BLXO", "P000BLXN", "P000BLXM", "P000BLXL", "P000BLXK", "P000BLXJ", "P000BLXI", "P000BLXH", "P000BLXG", "P000BLXF", "P000BLXE", "P000BLXD", "P000BLXC", "P000BLXB", "P000BLXA", "P000BLWZ", "P000BLWY", "P000BLWX", "P000BLWW", "P000BLWV", "P000BLWU", "P000BLWT", "P000BLWS", "P000BLWR", "P000BLWQ", "P000BLWP", "P000BLWO", "P000BLWN", "P000BLWM", "P000BLWL", "P000BLWK", "P000BLWJ", "P000BLWI", "P000BLWH", "P000BLWG", "P000BLWF", "P000BLWE", "P000BLWD", "P000BLWC", "P000BLWB", "P000BLWA", "P000BLVZ", "P000BLVY", "P000BLVX", "P000BLVW", "P000BLVV", "P000BLVU", "P000BLVT", "P000BLVS", "P000BLVR", "P000BLVQ", "P000BLVP", "P000BLVO", "P000BLVN", "P000BLVM", "P000BLVL", "P000BLVK", "P000BLVJ", "P000BLVI", "P000BLVH", "P000BLVG", "P000BLVF", "P000BLVE", "P000BLVD", "P000BLVC", "P000BLVB", "P000BLVA", "P000BLUZ", "P000BLUY", "P000BLUX", "P000BLUW", "P000BLUV", "P000BLUU", "P000BLUT", "P000BLUS", "P000BLUR", "P000BLUQ", "P000BLUP", "P000BLUO", "P000BLUN", "P000BLUM", "P000BLUL", "P000BLUK", "P000BLUJ", "P000BLUI", "P000BLUH", "P000BLUG", "P000BLUF", "P000BLUE", "P000BLUD", "P000BLUC", "P000BLUB", "P000BLUA", "P000BLTZ", "P000BLTY", "P000BLTX", "P000BLTW", "P000BLTV", "P000BLTU", "P000BLTT", "P000BLTS", "P000BLTR", "P000BLTQ", "P000BLTP", "P000BLTO", "P000BLTN", "P000BLTM", "P000BLTL", "P000BLTK", "P000BLTJ", "P000BLTI", "P000BLTH", "P000BLTG", "P000BLTF", "P000BLTE", "P000BLTD", "P000BLTC", "P000BLTB", "P000BLTA", "P000BLSZ", "P000BLSY", "P000BLSX", "P000BLSW", "P000BLSV", "P000BLSU", "P000BLST", "P000BLSS", "P000BLSR", "P000BLSQ", "P000BLSP", "P000BLSO", "P000BLSN", "P000BLSM", "P000BLSL", "P000BLSK", "P000BLSJ", "P000BLSI", "P000BLSH", "P000BLSG", "P000BLSF", "P000BLSE", "P000BLSD", "P000BLSC", "P000BLSB", "P000BLSA", "P000BLRZ", "P000BLRY", "P000BLRX", "P000BLRW", "P000BLRV", "P000BLRU", "P000BLRT", "P000BLRS", "P000BLRR", "P000BLRQ", "P000BLRP", "P000BLRO", "P000BLRN", "P000BLRM", "P000BLRL", "P000BLRK", "P000BLRJ", "P000BLRI", "P000BLRH", "P000BLRG", "P000BLRF", "P000BLRE", "P000BLRD", "P000BLRC", "P000BLRB", "P000BLRA", "P000BLQZ", "P000BLQY", "P000BLQX", "P000BLQW", "P000BLQV", "P000BLQU", "P000BLQT", "P000BLQS", "P000BLQR", "P000BLQQ", "P000BLQP", "P000BLQO", "P000BLQN", "P000BLQM", "P000BLQL", "P000BLQK", "P000BLQJ", "P000BLQI", "P000BLQH", "P000BLQG", "P000BLQF", "P000BLQE", "P000BLQD", "P000BLQC", "P000BLQB", "P000BLQA", "P000BLPZ", "P000BLPY", "P000BLPX", "P000BLPW", "P000BLPV", "P000BLPU", "P000BLPT", "P000BLPS", "P000BLPR", "P000BLPQ", "P000BLPP", "P000BLPO", "P000BLPN", "P000BLPM", "P000BLPL", "P000BLPK", "P000BLPJ", "P000BLPI", "P000BLPH", "P000BLPG", "P000BLPF", "P000BLPE", "P000BLPD", "P000BLPC", "P000BLPB", "P000BLPA", "P000BLOZ", "P000BLOY", "P000BLOX", "P000BLOW", "P000BLOV", "P000BLOU", "P000BLOT", "P000BLOS", "P000BLOR", "P000BLOQ", "P000BLOP", "P000BLOO", "P000BLON", "P000BLOM", "P000BLOL", "P000BLOK", "P000BLOJ", "P000BLOI", "P000BLOH", "P000BLOG", "P000BLOF", "P000BLOE", "P000BLOD", "P000BLOC", "P000BLOB", "P000BLOA", "P000BLNZ", "P000BLNY", "P000BLNX", "P000BLNW", "P000BLNV", "P000BLNU", "P000BLNT", "P000BLNS", "P000BLNR", "P000BLNQ", "P000BLNP", "P000BLNO", "P000BLNN", "P000BLNM", "P000BLNL", "P000BLNK", "P000BLNJ", "P000BLNI", "P000BLNH", "P000BLNG", "P000BLNF", "P000BLNE", "P000BLND", "P000BLNC", "P000BLNB", "P000BLNA", "P000BLMZ", "P000BLMY", "P000BLMX", "P000BLMW", "P000BLMV", "P000BLMU", "P000BLMT", "P000BLMS", "P000BLMR", "P000BLMQ", "P000BLMP", "P000BLMO", "P000BLMN", "P000BLMM", "P000BLML", "P000BLMK", "P000BLMJ", "P000BLMI", "P000BLMH", "P000BLMG", "P000BLMF", "P000BLME", "P000BLMD", "P000BLMC", "P000BLMB", "P000BLMA", "P000BLLZ", "P000BLLY");
//        List<String> c24CodeList = Arrays.asList("P0000EAZ", "P0000MQF", "P0000VNI", "P0000VPE", "P0000WKA", "P0000WOP", "P0000WOQ", "P0000WOR", "P0000WOY", "P0000WPG", "P0000WPI", "P0000WPK", "P0000WPR", "P0000WQI", "P0000WQJ", "P0000WQS", "P0000WRH", "P0000WRN", "P0000WRZ", "P0000WSI", "P0000WSO", "P0000WSQ", "P0000WSR", "P0000WSS", "P0000WSZ", "P0000WTA", "P0000WTB", "P0000WTC", "P0000WTI", "P0000WTL", "P0000WTP", "P0000WTY", "P0000WTZ", "P0000WUA", "P0000WUE", "P0000WUN", "P0000WUU", "P0000WWM", "P0000WYJ", "P0000WZK", "P0000KEL", "P0000LEW", "P0000XQV", "P0000XSV", "P0000XTW", "P0000YAK", "P0000YAM", "P0000YEY", "P0000YFJ", "P0000YHD", "P0000YHF", "P0000YHV", "P0000YPR", "P0000YPS", "P0000YQU", "P0000YSW", "P0000YTD", "P0000ZFG", "P0000ZPI", "P0000ZRO", "P0000ZUM", "P0000ZVL", "P0000ZVM", "P0000ZZL", "P000BAJZ", "P000BAKY", "P000BAOB", "P000BAPM", "P000BAUG", "P000BAUS", "P000BAUU", "P000BAVU", "P000BAWA", "P000BAXC", "P000BAXD", "P000BAXE", "P000BBBI", "P000BBCU", "P000BBEA", "P000BBEB", "P000BBSA", "P000BCJL", "P000BCSK", "P000BCSN", "P000BCTC", "P000BCTF", "P000BCTG", "P000BCTH", "P000BCTI", "P000BDXA", "P000BDXB", "P000BDXC", "P000BDXD", "P000BECM", "P000BEJN", "P000BEJO", "P000BEJP", "P000BEJQ", "P000BFBD", "P000BFIF", "P0000LZQ", "P0000LZR", "P0000LZS", "P0000LZT", "P0000LZU", "P0000LZV", "P0000LZW", "P0000LZX", "P0000OTX", "P0000PZJ", "P000BGRB", "P000BGYW", "P000BHWI", "P000BIBO", "P000BIBP", "P000BIHK", "P000BIHO", "P000BJDL", "P000BJGT", "P000BJPE", "P000BJPF", "P000BJPG", "P000BJPH", "P000BJPI", "P000BJPJ", "P000BJPK", "P000BJPL", "P000BJPM", "P000BJPN", "P000BJPO", "P000BJPR", "P000BJQV", "P000BJSM", "P000BJSN", "P000BJSO", "P000BJTN", "P000BJTP", "P000BJTQ", "P000BJUJ", "P000BJUK", "P000BJUL", "P000BJWE", "P000BJXK", "P000BJXL", "P000BJXM", "P000BJYV", "P000BJYW", "P000BJYY", "P000BKFQ", "P000BKHF", "P000BKIX", "P000BKIY", "P000BKJR", "P000BKKT", "P000BKKU", "P000BKKW", "P000BKKX", "P000BKLU", "P000BKMM", "P000BKTG", "P000BKTH", "P000BKTI", "P000BKUR", "P000BKUR", "P000BKWE", "P000BKWF", "P000BKWR", "P000BKWS", "P000BKWT", "P000BKWV", "P000BKXF", "P000BKXP", "P000BKXS", "P000BKXT", "P000BKXU", "P000BKYU", "P000BKZA", "P000BKZE", "P000BKZF", "P000BKZG", "P000BKZI", "P000BKZO", "P000BKZP", "P000BLBU", "P000BLHF", "P000BLHG", "P000BLIU", "P000BLIV", "P000BLIW", "P000BLJA", "P000BLJB", "P000BLJC", "P000BLJD", "P000BLJE", "P000BLJG", "P000BLJH", "P000BLLR", "P000BLLS", "P000BLLT", "P000BLLU", "P000BLLV", "P000BLLW", "P000BLTH", "P000BMEQ", "P000BMER", "P000BMES", "P000BMET", "P000BMEU", "P000BMEV", "P000BMEX", "P000BMEY", "P000BMEZ", "P000BMFC", "P000BMFD", "P000BMFE", "P000BMFF", "P000BMFG", "P000BMFH", "P000BMFI", "P000BMFJ", "P000BMFK", "P000BMFL", "P000BMFM", "P000BMFN", "P000BMFO", "P000BMFP", "P000BMFQ", "P000BMFR", "P000BMFS", "P000BMFT", "P000BMFU", "P000BMFV", "P000BMFW", "P000BMFZ", "P000BMGC", "P000BMGE", "P000BMGF", "P000BMGG", "P000BMGH", "P000BMGI", "P000BMGJ", "P000BMGK", "P000BMGL", "P000BMGM", "P000BMGN", "P000BMGQ", "P000BMGS", "P000BMGT", "P000BMGU");
//        List<String> c24CodeList = Arrays.asList("P0000MEP", "P0000JYL", "P0000GEC");
        List<String> c24CodeList = Arrays.asList("P0000ZQW", "P000BCIS");
        crawlProductController.renewCostcoProductByC24CodeList(today, c24CodeList);
        System.out.println("renewCostcoProductByC24CodeList() finished");
        fileController.resizeDailyImages(today);
        System.out.println("resizeDailyImages() finished");

        return "process finished";

    }

    @GetMapping("/1688-a")
    public String run1688A() throws Exception {
        // todo : 1. 상품명 상품가격 배송비 옵션정보(옵션 종류별) 크롤링 / 2. 상품명 상품상세(이미지) 상품썸네일(이미지) 옵션명(옵션a|옵션b...) specInfo 번역 / 3. 일자별 환율 db에 입력하고 상품 가격 계산 (185원 per CNY)
        // 다양한 옵션 형태 https://detail.1688.com/offer/699265952257.html / https://detail.1688.com/offer/750401695002.html / https://detail.1688.com/offer/686998944186.html
        // 옵션 종류 sku-module-wrapper > sku-item-wrapper > sku-item-name & discountPrice-price
        crawlService.setDriverProperty();
        WebDriver driver = crawlService.createWebDriver1688();

        LocalDate today = LocalDate.now();
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));
        try {
            commonUtil.generateDailyDirectories1688(formatToday);
        } catch (IOException e) {
            throw new CrawlException(CrawlException.Type.BAD_REQUEST, String.format("directory creation failed. %s", e.getMessage()));
        }

        // Scanner 객체 생성
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("크롤링하시겠습니까? 크롤링 준비가 완료된 경우, Y 키를 누르십시오... (Y/N)");
            String answer = "";
            while (scanner.hasNextLine()) {
                answer = scanner.nextLine().trim().toUpperCase();
                // 'Y' 또는 'N' 입력을 기다림
                if (answer.equals("Y") || answer.equals("N")) {
                    break; // 유효한 입력이면 반복문 탈출
                } else {
                    System.out.println("Y 또는 N을 입력해 주세요.");
                }
            }

            if ("N".equals(answer)) {
                break; // 'N'이 입력되면 루프 종료
            }

            // 사용자가 'Y'를 입력하면 크롤링을 진행
            System.out.println("크롤링을 진행합니다.");

            Long productCode = crawlProductController.crawlCurrentPage1688(formatToday, driver);
            System.out.println("crawlCurrentPage1688() finished");
            System.out.println("페이지 타이틀: " + productCode);
        }

        // 크롤링 종료 후 자원 정리
        driver.quit();
        scanner.close();
        return "process finished";
    }

    @GetMapping("/costco-b")
    public String runCostcoB() throws IOException {
        // http://localhost:5001/run/costco-b
        LocalDate today = LocalDate.now();
        fileController.ftpUploadDailyImages(today);
        System.out.println("ftpUploadDailyImages() finished");
        fileController.s3UploadImagesPublic(today);
        System.out.println("s3UploadImagesPublic() finished");
        fileController.exportExcel(today);
        System.out.println("exportExcel() finished");
        return "process finished";
    }

    @GetMapping("/costco-c")
    public String runCostcoC() throws IOException {
            // 해당 기능이 exportExcel() 함수에 합쳐졌음
            // http://localhost:5001/run/costco-c
        LocalDate today = LocalDate.now();
        fileController.exportUnavailableExcel(today);
        return "process finished";
    }

    @GetMapping("/costco-test")
    public String runCostcoTest() throws IOException {
/*
        LocalDate today = LocalDate.now();
        crawlProductController.renewProduct(today);
        System.out.println("renewProduct() finished");
        return "process finished";
*/
        LocalDate today = LocalDate.now();
        fileController.exportExcel(today);
        return "process finished";
    }

    @GetMapping("/costco-all")
    public String runCostcoAll() throws IOException {
        LocalDate today = LocalDate.now();
        crawlCategoryController.renewCategory();
        System.out.println("renewCategory() finished");
        crawlProductController.renewCostcoProduct(today);
        System.out.println("renewProduct() finished");
        fileController.resizeDailyImages(today);
        System.out.println("resizeDailyImages() finished");
        fileController.ftpUploadDailyImages(today);
        System.out.println("ftpUploadDailyImages() finished");
        fileController.s3UploadImagesPublic(today);
        System.out.println("s3UploadImagesPublic() finished");
        fileController.exportExcel(today);
        System.out.println("exportExcel() finished");
//        fileController.exportUnavailableExcel(today);
        return "process finished";
    }

    @GetMapping("/translate-image")
    public String translateImage() throws IOException {
        LocalDate today = LocalDate.now();
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));

        String fileName = "O1CN0171bwzc25IQZHdwvpS_!!2213833287503-0-cib.jpg";
        String imagePath = localImagesDirectory1688 + "/" + fileName;
        String koDirectory = String.join("/", localDailyDirectory1688, formatToday, "ko");
        commonUtil.generateDirectories(koDirectory);

        String outputPath = koDirectory + "/" + fileName;
        translateService.translateImage(imagePath, outputPath, "");
        return "process finished";
    }

    @GetMapping("/detect-text")
    public String detectTextFromImage() {
        LocalDate today = LocalDate.now();
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));

        String fileName = "O1CN0171bwzc25IQZHdwvpS_!!2213833287503-0-cib.jpg";
        String imagePath = localImagesDirectory1688 + "/" + fileName;
        return translateService.getDetectedTextFromImage(imagePath);
    }

    @GetMapping("/translate-text")
    public String translateText() {
        String text = "亚克力流体解压装饰摆件 抖音泰坦尼克号黑珍珠号漂浮亚克力 万里阳光号 SUNSHINE 用心做产品 一心为客户 厂家直销质量保证 飘破浪 源头 厂家 亚克力 流体 解压 装饰 摆件 抖 音 泰坦尼克 号 黑 珍珠 号 漂浮 亚克力 万里 阳光 号 SUNSHINE 用心 做 产品 一心 为 客户 厂家 直销 质量 保证 飘 破浪 源头 厂家";
//        String detect = translateService.getDetectLanguageCodeNCP(text);
        String translate = translateService.translateText(text, "zh-CN", "ko");
//        System.out.println(detect);
        System.out.println(translate);
//        return String.join("/", detect, translate);
        return translate;
    }

    @GetMapping("/is-containing-chinese")
    public Boolean isContainingChinese() {
        String text = "亚克力流体解压装饰摆件 抖音泰坦尼克号黑珍珠号漂浮亚克力 万里阳光号 SUNSHINE 用心做产品 一心为客户 厂家直销质量保证 飘破浪 源头 厂家 亚克力 流体 解压 装饰 摆件 抖 音 泰坦尼克 号 黑 珍珠 号 漂浮 亚克力 万里 阳光 号 SUNSHINE 用心 做 产品 一心 为 客户 厂家 直销 质量 保证 飘 破浪 源头 厂家";
        Boolean isChinese = commonUtil.isContainingChinese(text);
        return isChinese;
    }

    @GetMapping("/calc-chinese-percentage")
    public double calcChinesePercentage() {
        String text = "亚克力流体解压装饰摆件 抖音泰坦尼克号黑珍珠号漂浮亚克力 万里阳光号 SUNSHINE 用心做产品 一心为客户 厂家直销质量保证 飘破浪 源头 厂家 亚克力 流体 解压 装饰 摆件 抖 音 泰坦尼克 号 黑 珍珠 号 漂浮 亚克力 万里 阳光 号 SUNSHINE 用心 做 产品 一心 为 客户 厂家 直销 质量 保证 飘 破浪 源头 厂家";
        return commonUtil.calcChineseCharactersRatio(text);
    }

    @PostMapping("/images/1688/download-daily")
    public void downloadDailyImages1688(
            @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate today
    ) throws IOException {
        // download 1688 product related images (thumbnail and detail) from startDate
        // detail_item_main_images_1688 & description_item_1688
        // image download
        // todo =>>> move to fileController
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));

        // get all detailItemMainImages
        List<String> urlList = new ArrayList<>(productDao.getDailyDetailItemMainImages1688());
        productDao.getDailyDescriptionItemImageUrlTexts1688()
                .forEach(imageUrlText -> {
            urlList.addAll(commonUtil.convertStringToList(imageUrlText));
        });
        commonUtil.downloadImages1688(urlList, formatToday);
    }

    @PostMapping("/images/1688/translate-daily")
    public void translateDailyImages1688(
            @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate today
    ) throws IOException {
        // todo =>>> move to fileController
        String formatToday = today.format(DateTimeFormatter.ofPattern("yyMMdd"));
        String dailyImageDirectory = String.join("/", localDailyDirectory1688, formatToday, "images");

        String dailyKoDirectory = String.join("/", localDailyDirectory1688, formatToday, "ko");

        // check image contains chinese & translate images in directory
        Set<String> sortedFilenameSet = commonUtil.getSortedFilenameSet(dailyImageDirectory, localKoDirectory1688);
        sortedFilenameSet.forEach(filename -> {
            String imagePath = Paths.get(dailyImageDirectory, filename).toString();
            String detectedText = translateService.getDetectedTextFromImage(imagePath);

            if (commonUtil.isContainingChinese(detectedText)) {
                String outputImagePath = Paths.get(localKoDirectory1688, filename).toString();
                translateService.translateImage(imagePath, outputImagePath, dailyKoDirectory);
            }
        });
    }

    @PostMapping("/c24/1688/transform-daily")
    public void transformDailyProductIntoC241688(
            @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate today
    ) {
        // todo 3 : -> text translate and insert as c24 format
        // todo steps : 상품 데이터를 transform 함 >
        //  상품 d-example_50.xlsx 양식 >
        //  상품 활성화 양식 >
        //  상품 옵션 초기화 양식 (옵션전용 테이블은 만들지 않음) >
        //  상품 재고관리 양식 (옵션관리 테이블<c24_product_option_stock_1688> 별도로 생성해야함 옵션 코드는 000A 이런식으로)
        //  이후에 상품 일괄보내기 해야함
        // c24_product_1688 테이블에 옵션 타입에 대한 부분 추가하기 / props / 옵션-분리형 S or 일체형 C
        // sku_props count 갯수가 단일일 경우에는 C 여러개인 경우 S 로 하자
        // 옵션 초기화 양식으로 업로드 진행 시 옵션 코드가 어떻게 적용되는지 체크할 필요가 있다. 000A ...B C D E F...Z 00BA ... 00BZ 00CA
        // 颜色 -> 색상
        // 型号 -> 모델 - containing

        //재고 관리

    }

}
